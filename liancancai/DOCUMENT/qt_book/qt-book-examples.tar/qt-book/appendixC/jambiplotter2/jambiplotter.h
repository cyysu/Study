#include <QtGui>

#include "../plotter/plotter.h"
